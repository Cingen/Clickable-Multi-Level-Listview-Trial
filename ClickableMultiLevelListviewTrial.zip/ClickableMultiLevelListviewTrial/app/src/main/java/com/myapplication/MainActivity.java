package com.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ExpandableListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity implements ThreeLevelListAdapter.ThreeLevelListViewListener{
    private ExpandableListView expandableListView;

    String[] parent = new String[]{"group 1", "group 2"};
    String[] q1 = new String[]{"Child Level 1", "Child level 2"};
    String[] q2 = new String[]{"Child Level 1B", "Child Level 2B"};
    String[] q3 = new String[]{"Child Level 1C"};
    String[] des1 = new String[]{"A","B","C"};
    String[] des2 = new String[]{"D","E","F"};
    String[] des3 = new String[]{"G"};
    String[] des4 = new String[]{"H","J"};
    String[] des5 = new String[]{"U."," R"," V"};

    LinkedHashMap<String, String[]> thirdLevelq1 = new LinkedHashMap<>();
    LinkedHashMap<String, String[]> thirdLevelq2 = new LinkedHashMap<>();
    LinkedHashMap<String, String[]> thirdLevelq3 = new LinkedHashMap<>();
    /**
     * Second level array list
     */
    List<String[]> secondLevel;
    /**
     * Inner level data
     */
    List<LinkedHashMap<String, String[]>> data = new ArrayList<>();

    public MainActivity() {
        secondLevel = new ArrayList<>();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setUpAdapter();
    }

    private void setUpAdapter() {
        secondLevel.add(q1);
        secondLevel.add(q2);
        secondLevel.add(q3);
        thirdLevelq1.put(q1[0], des1);
        thirdLevelq1.put(q1[1], des2);
        thirdLevelq2.put(q2[0], des3);
        thirdLevelq2.put(q2[1], des4);
        thirdLevelq3.put(q3[0], des5);

        data.add(thirdLevelq1);
        data.add(thirdLevelq2);
        data.add(thirdLevelq3);
        expandableListView = (ExpandableListView) findViewById(R.id.expandible_listview);
        //passing three level of information to constructor
        ThreeLevelListAdapter threeLevelListAdapterAdapter = new ThreeLevelListAdapter(this, parent, secondLevel, data, this);
        expandableListView.setAdapter(threeLevelListAdapterAdapter);
        expandableListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            int previousGroup = -1;
            @Override
            public void onGroupExpand(int groupPosition) {
                if (groupPosition != previousGroup)
                    expandableListView.collapseGroup(previousGroup);
                previousGroup = groupPosition;
            }
        });
    }

    @Override
    public void onFinalChildClick(int plpos, int slpos, int tlpos) {
        //Toast.makeText(this, plpos + ", " + slpos + ", " + tlpos, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onFinalItemClick(String plItem, String slItem, String tlItem) {
        Toast.makeText(this, plItem + ", " + slItem + ", " + tlItem, Toast.LENGTH_SHORT).show();
    }
}
